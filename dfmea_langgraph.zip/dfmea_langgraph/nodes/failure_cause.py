"""
nodes/failure_cause.py
======================
Generates failure causes for every selected failure mode × lower connection.
Calls services/generation_utils.generate_causes_for_mode().

Case 1 note: all causes must be noise-driven (enforced by prompt in generation_utils).

Reads:  failure_modes (selected ones), elements, noise_factors, import_case
Writes: failure_causes, failure_cause_status
"""

import uuid
from dfmea_state import DFMEAState, TaskStatus, FailureCause, ImportCase
from services.generation_utils import generate_causes_for_mode
from llm_client import llm


def _uid() -> str:
    return str(uuid.uuid4())[:8]


def failure_cause_node(state: DFMEAState) -> dict:
    # Build noise_factors dict {category: [factors]}
    noise_dict: dict[str, list[str]] = {}
    for nf in state.get("noise_factors", []):
        cat = nf.get("category", "General")
        noise_dict.setdefault(cat, []).append(nf.get("factor", ""))

    # Build lower connections from B-diagram
    elem_map = {e["key"]: e for e in state.get("elements", [])}
    lower_connections = [
        {
            "lower_element":  elem_map.get(conn.get("from_key", ""), {}).get("name", conn.get("from_key", "")),
            "lower_function": fn,
        }
        for conn in state.get("b_connections", [])
        for e_key in [conn.get("from_key", "")]
        if elem_map.get(e_key, {}).get("level") == "lower"
        for fn in elem_map.get(e_key, {}).get("functions", [""])
    ]
    # Deduplicate
    seen = set()
    unique_lower = []
    for lc in lower_connections:
        key = (lc["lower_element"], lc["lower_function"])
        if key not in seen:
            seen.add(key)
            unique_lower.append(lc)

    # Focus element
    focus_elem = next((e for e in state.get("elements", []) if e.get("level") == "focus"), {})

    # Selected failure modes only
    selected_modes = [m for m in state.get("failure_modes", []) if m.get("selected")]

    all_causes: list[FailureCause] = []

    for mode in selected_modes:
        # Determine focus function for this mode's element
        mode_elem = next(
            (e for e in state.get("elements", []) if e.get("name") == mode.get("element")),
            focus_elem,
        )
        focus_function = mode_elem.get("functions", [""])[0] if mode_elem.get("functions") else ""

        for lc in unique_lower:
            try:
                causes = generate_causes_for_mode(
                    focus_element=mode_elem.get("name", ""),
                    focus_function=focus_function,
                    failure_mode=mode.get("mode", ""),
                    lower_element=lc["lower_element"],
                    lower_function=lc["lower_function"],
                    noise_factors=noise_dict,
                    llm=llm,
                )
            except Exception:
                causes = [{
                    "cause": f"Noise-induced {mode.get('mode', 'failure')}",
                    "noise_category": "General",
                    "noise_factor": "Variation",
                }]

            for c in causes:
                all_causes.append(FailureCause(
                    id=_uid(),
                    failure_mode_id=mode.get("id", ""),
                    cause=c.get("cause", ""),
                    noise_category=c.get("noise_category", ""),
                    noise_factor=c.get("noise_factor", ""),
                    selected=False,
                    prevention_methods="",
                    detection_methods="",
                    occurrence_answer="",
                    detection_answer="",
                ))

    return {
        "failure_causes":       all_causes,
        "failure_cause_status": TaskStatus.RUNNING,
    }
