"""
nodes/export_node.py
====================
Writes dfmea_rows → Template_DFMEA.xlsx and ifmea_rows → IFMEA sheet.
Calls services/export_utils.

Reads:  dfmea_rows, ifmea_rows, project_name
Writes: export_path (DFMEA), ifmea_export_path, export_status
"""

import os
import uuid
from dfmea_state import DFMEAState, TaskStatus
from services.export_utils import export_dfmea_to_buffer, export_ifmea_to_buffer

OUTPUT_DIR = os.environ.get("DFMEA_OUTPUT_DIR", "/tmp/dfmea_exports")


def export_node(state: DFMEAState) -> dict:
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    run_id = str(uuid.uuid4())[:8]
    project = state.get("project_name", "DFMEA").replace(" ", "_")

    results = {}

    # ── DFMEA export ─────────────────────────────────────────────────────────
    dfmea_rows = state.get("dfmea_rows", [])
    if dfmea_rows:
        try:
            buf  = export_dfmea_to_buffer(dfmea_rows)
            path = os.path.join(OUTPUT_DIR, f"{project}_{run_id}_DFMEA.xlsx")
            with open(path, "wb") as f:
                f.write(buf.read())
            results["export_path"] = path
        except Exception as exc:
            return {
                "export_status": TaskStatus.FAILED,
                "export_error":  f"DFMEA export failed: {exc}",
            }

    # ── IFMEA export ─────────────────────────────────────────────────────────
    ifmea_rows = state.get("ifmea_rows", [])
    if ifmea_rows:
        try:
            buf  = export_ifmea_to_buffer(ifmea_rows)
            path = os.path.join(OUTPUT_DIR, f"{project}_{run_id}_IFMEA.xlsx")
            with open(path, "wb") as f:
                f.write(buf.read())
            results["ifmea_export_path"] = path
        except Exception as exc:
            return {
                "export_status": TaskStatus.FAILED,
                "export_error":  f"IFMEA export failed: {exc}",
            }

    return {
        **results,
        "export_status": TaskStatus.DONE,
        "export_error":  None,
    }
