"""
nodes/mode_select.py
====================
Human-in-the-loop pause for failure mode selection.

Interrupts and waits for frontend to POST back:
  { failure_modes: FailureModeRecord[] }  (with selected: true/false)

Reads:  failure_modes
Writes: failure_modes (with selections), failure_mode_status = DONE
"""

from langgraph.types import interrupt
from dfmea_state import DFMEAState, TaskStatus


def mode_select(state: DFMEAState) -> dict:
    user_input = interrupt({
        "step":    "mode_select",
        "message": "Select the failure modes you want to analyse.",
        "state":   {"failure_modes": state.get("failure_modes", [])},
    })
    return {
        "failure_modes":       user_input.get("failure_modes", state.get("failure_modes", [])),
        "failure_mode_status": TaskStatus.DONE,
    }
