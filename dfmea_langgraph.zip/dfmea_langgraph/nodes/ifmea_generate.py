"""
nodes/ifmea_generate.py
=======================
Generates IFMEA causes and effects for each B-diagram connection.
Reuses selected DFMEA failure modes (not generating new modes — same functional
failures, different causal path through the interface).
Calls services/ifmea_utils.

Reads:  b_connections, elements, failure_modes (selected), noise_factors
Writes: ifmea_interfaces, ifmea_status = RUNNING
"""

import uuid
from dfmea_state import DFMEAState, TaskStatus, IFMEAInterface, IFMEAModeRecord
from services.ifmea_utils import (
    generate_interface_causes_bulk,
    generate_interface_effect,
    rate_interface_severity,
)
from llm_client import llm


def _uid() -> str:
    return str(uuid.uuid4())[:8]


def ifmea_generate(state: DFMEAState) -> dict:
    connections = state.get("b_connections", [])
    if not connections:
        return {"ifmea_status": TaskStatus.SKIPPED, "ifmea_interfaces": []}

    elem_map = {e["key"]: e for e in state.get("elements", [])}

    # Build noise dict
    noise_dict: dict[str, list[str]] = {}
    for nf in state.get("noise_factors", []):
        noise_dict.setdefault(nf.get("category", "General"), []).append(nf.get("factor", ""))

    # Selected DFMEA failure modes — reused for interface cause generation
    selected_modes = [m.get("mode", "") for m in state.get("failure_modes", []) if m.get("selected")]

    interfaces: list[IFMEAInterface] = []

    for conn in connections:
        from_elem = elem_map.get(conn.get("from_key", ""), {})
        to_elem   = elem_map.get(conn.get("to_key", ""),   {})
        from_name = from_elem.get("name", conn.get("from_key", ""))
        to_name   = to_elem.get("name",   conn.get("to_key", ""))
        conn_type = conn.get("conn_type", "P")
        nominal   = conn.get("label", "")

        # Higher element functions (to → higher function lookup for effects)
        higher_fns = to_elem.get("functions", []) if to_elem.get("level") == "higher" else []

        # focus_function: first function of from_element
        focus_fn = from_elem.get("functions", [""])[0] if from_elem.get("functions") else ""

        # Generate causes per mode × noise factor
        try:
            cause_groups = generate_interface_causes_bulk(
                from_element=from_name,
                to_element=to_name,
                connection_type=conn_type,
                nominal_transfer=nominal,
                focus_function=focus_fn,
                dfmea_failure_modes=selected_modes,
                noise_factors=noise_dict,
                llm=llm,
            )
        except Exception:
            cause_groups = []

        # Build interface cause rows (flat), generate effects + severity for each
        cause_rows = []
        for group in cause_groups:
            for c in group.get("causes", []):
                cause_text = c.get("cause", "")
                if not cause_text:
                    continue

                # Generate effect
                try:
                    effect = generate_interface_effect(
                        from_element=from_name,
                        to_element=to_name,
                        connection_type=conn_type,
                        nominal_transfer=nominal,
                        failure_mode=group.get("failure_mode", ""),
                        interface_cause=cause_text,
                        higher_element_functions=higher_fns,
                        llm=llm,
                    )
                except Exception:
                    effect = ""

                # Rate severity
                try:
                    sev_result = rate_interface_severity(
                        to_element=to_name,
                        failure_effect=effect,
                        higher_element_functions=higher_fns,
                        llm=llm,
                    )
                    severity = sev_result.get("severity_rank", 5)
                except Exception:
                    severity = 5

                cause_rows.append({
                    "id":             _uid(),
                    "failure_mode":   group.get("failure_mode", ""),
                    "cause":          cause_text,
                    "noise_category": c.get("noise_category", ""),
                    "noise_factor":   c.get("noise_factor", ""),
                    "failure_effect": effect,
                    "severity":       severity,
                    "selected":       False,
                    "prevention_controls": "",
                    "detection_controls":  "",
                    "occurrence_answer":   "",
                    "detection_answer":    "",
                })

        # Build IFMEAModeRecord list from the selected DFMEA modes
        mode_records = [
            IFMEAModeRecord(id=_uid(), mode=m, selected=True)
            for m in selected_modes
        ]

        interfaces.append(IFMEAInterface(
            conn_id=conn.get("id", _uid()),
            from_element=from_name,
            to_element=to_name,
            conn_type=conn_type,
            nominal_transfer=nominal,
            failure_modes=mode_records,
            causes=cause_rows,
            modes_loading=False,
            modes_generated=True,
        ))

    return {
        "ifmea_interfaces": interfaces,
        "ifmea_status":     TaskStatus.RUNNING,
    }
