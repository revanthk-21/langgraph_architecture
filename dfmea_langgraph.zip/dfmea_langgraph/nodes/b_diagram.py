"""
nodes/b_diagram.py
==================
Human-in-the-loop pause for B-Diagram drawing / confirmation.

Interrupts and waits for frontend to POST back:
  { elements, b_connections, b_diagram_svg? }

Reads:  elements, b_connections (may be pre-filled by parse_node)
Writes: elements, b_connections, b_diagram_svg
"""

from langgraph.types import interrupt
from dfmea_state import DFMEAState


def b_diagram_checkpoint(state: DFMEAState) -> dict:
    user_input = interrupt({
        "step":    "b_diagram",
        "message": "Draw or confirm the B-Diagram, then continue.",
        "state": {
            "elements":      state.get("elements", []),
            "b_connections": state.get("b_connections", []),
        },
    })
    return {
        "elements":      user_input.get("elements",      state.get("elements", [])),
        "b_connections": user_input.get("b_connections", state.get("b_connections", [])),
        "b_diagram_svg": user_input.get("b_diagram_svg"),
    }
