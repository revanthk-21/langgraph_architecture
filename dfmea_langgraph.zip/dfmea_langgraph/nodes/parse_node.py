"""
nodes/parse_node.py
===================
Runs the universal DFMEA xlsx parser (Case 2 & 3).
Reads:  uploaded_file_path, import_case, elements
Writes: parsed_import, b_connections, noise_factors, dfmea_rows, parse_status
"""

from dfmea_state import DFMEAState, TaskStatus, ImportCase
from dfmea_universal_parser import parse_dfmea_file, apply_consolidation
from pathlib import Path
import tempfile


def parse_node(state: DFMEAState) -> dict:
    file_path = state.get("uploaded_file_path")
    if not file_path:
        return {"parse_status": TaskStatus.FAILED, "parse_error": "No uploaded_file_path in state."}

    elements = state.get("elements", [])
    focus    = next((e["name"] for e in elements if e.get("level") == "focus"), "")
    higher   = [e["name"] for e in elements if e.get("level") == "higher"]
    lower    = [e["name"] for e in elements if e.get("level") == "lower"]

    try:
        parsed = parse_dfmea_file(file_path, elements={"focus": focus, "higher": higher, "lower": lower})
        parsed = apply_consolidation(parsed)
    except Exception as exc:
        return {"parse_status": TaskStatus.FAILED, "parse_error": str(exc)}

    return {
        "parsed_import":  parsed,
        "b_connections":  parsed.get("connections", []),
        "noise_factors":  [
            {"id": f"nf_{i}", "category": cat, "factor": f}
            for cat, factors in parsed.get("noise_factors", {}).items()
            for i, f in enumerate(factors)
        ],
        "dfmea_rows":     parsed.get("dfmea_rows", []),
        "parse_status":   TaskStatus.DONE,
        "parse_error":    None,
    }
