"""
nodes/failure_mode.py
=====================
Generates DFMEA failure modes for every element × function in state.
Calls services/generation_utils.generate_failure_modes().

Reads:  elements
Writes: failure_modes, failure_mode_status
"""

import uuid
from dfmea_state import DFMEAState, TaskStatus, FailureModeRecord
from services.generation_utils import generate_failure_modes
from llm_client import llm


def _uid() -> str:
    return str(uuid.uuid4())[:8]


def failure_mode_node(state: DFMEAState) -> dict:
    elements = state.get("elements", [])
    all_modes: list[FailureModeRecord] = []

    for elem in elements:
        for fn in elem.get("functions", []):
            try:
                modes = generate_failure_modes(
                    focus_function_name=fn,
                    focus_element_name=elem.get("name", ""),
                    llm=llm,
                )
            except Exception:
                modes = [
                    f"{fn} — complete loss",
                    f"{fn} — degraded performance",
                    f"{fn} — intermittent failure",
                ]

            for mode in modes:
                all_modes.append(FailureModeRecord(
                    id=_uid(),
                    mode=mode,
                    element=elem.get("name", ""),
                    selected=False,
                ))

    return {
        "failure_modes":       all_modes,
        "failure_mode_status": TaskStatus.RUNNING,   # DONE after mode_select
    }
