"""
nodes/risk_rating.py
====================
Converts qualitative answers → O, D, RPN, AP for every selected cause.
Also runs LLM-based severity rating via failure effects.
Calls services/risk_utils.rate_cause_row() and rate_severity_llm().

Reads:  failure_causes (selected, with occurrence_answer + detection_answer),
        failure_modes (for effect lookup),
        elements (for higher function lookup)
Writes: failure_causes (with occurrence, detection, severity, rpn, action_priority),
        risk_rating_status
"""

from dfmea_state import DFMEAState, TaskStatus, FailureCause
from services.risk_utils import rate_cause_row, rate_severity_llm
from llm_client import llm


def risk_rating_node(state: DFMEAState) -> dict:
    mode_map = {m["id"]: m for m in state.get("failure_modes", [])}

    # Build higher function lookup: element_name → [functions]
    higher_fn_map: dict[str, list[str]] = {}
    for elem in state.get("elements", []):
        if elem.get("level") == "higher":
            higher_fn_map[elem["name"]] = elem.get("functions", [])

    # First, build failure effects for each (mode, higher_element) pair if not already present.
    # We use a simple cache: mode_id → failure_effect
    effect_cache: dict[str, str] = {}
    for mode in state.get("failure_modes", []):
        if not mode.get("selected"):
            continue
        if mode.get("id") in effect_cache:
            continue
        # Pick first higher element's first function as representative
        higher_elems = [e for e in state.get("elements", []) if e.get("level") == "higher"]
        if higher_elems:
            he = higher_elems[0]
            hfn = he.get("functions", [""])[0] if he.get("functions") else ""
            focus_elem = next(
                (e for e in state.get("elements", []) if e.get("name") == mode.get("element")), {}
            )
            focus_fn = focus_elem.get("functions", [""])[0] if focus_elem.get("functions") else ""
            try:
                from services.generation_utils import generate_effect
                effect = generate_effect(
                    focus_element=mode.get("element", ""),
                    focus_function=focus_fn,
                    failure_mode=mode.get("mode", ""),
                    higher_element=he.get("name", ""),
                    higher_function=hfn,
                    llm=llm,
                )
                effect_cache[mode["id"]] = effect
            except Exception:
                effect_cache[mode["id"]] = ""
        else:
            effect_cache[mode["id"]] = ""

    # Now rate each selected cause
    updated_causes: list[FailureCause] = []
    for cause in state.get("failure_causes", []):
        if not cause.get("selected"):
            updated_causes.append(cause)
            continue

        mode = mode_map.get(cause.get("failure_mode_id", ""), {})
        failure_effect = effect_cache.get(cause.get("failure_mode_id", ""), "")

        # Severity from LLM if we have an effect
        if failure_effect:
            higher_fn = ""
            higher_elems = [e for e in state.get("elements", []) if e.get("level") == "higher"]
            if higher_elems:
                higher_fn = ", ".join(higher_elems[0].get("functions", []))
            try:
                sev_result = rate_severity_llm(higher_fn, failure_effect, llm)
                severity = sev_result.get("severity_rank", 5)
            except Exception:
                severity = 5
        else:
            severity = cause.get("severity", 5) or 5

        # O/D/RPN/AP from qualitative answers
        ratings = rate_cause_row(
            severity=severity,
            occurrence_answer=cause.get("occurrence_answer", "moderate"),
            detection_answer=cause.get("detection_answer", "moderate"),
        )

        updated_causes.append({
            **cause,
            "severity":        severity,
            "failure_effect":  failure_effect,
            **ratings,
        })

    return {
        "failure_causes":     updated_causes,
        "risk_rating_status": TaskStatus.DONE,
    }
