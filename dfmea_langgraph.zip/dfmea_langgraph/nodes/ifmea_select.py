"""
nodes/ifmea_select.py
=====================
Human-in-the-loop pause for IFMEA cause selection, rating, and matrix.

Interrupts and waits for frontend to POST back:
  {
    ifmea_interfaces: IFMEAInterface[]   (causes with selected + O/D answers),
    ifmea_matrix: [...]                  (n×n interface rating matrix, optional)
  }

Reads:  ifmea_interfaces
Writes: ifmea_interfaces, ifmea_matrix, ifmea_status = DONE
"""

from langgraph.types import interrupt
from dfmea_state import DFMEAState, TaskStatus


def ifmea_select(state: DFMEAState) -> dict:
    user_input = interrupt({
        "step":    "ifmea_select",
        "message": "Review IFMEA causes, select, rate, and complete the interface matrix.",
        "state": {
            "ifmea_interfaces": state.get("ifmea_interfaces", []),
        },
    })
    return {
        "ifmea_interfaces": user_input.get("ifmea_interfaces", state.get("ifmea_interfaces", [])),
        "ifmea_matrix":     user_input.get("ifmea_matrix"),
        "ifmea_status":     TaskStatus.DONE,
    }
