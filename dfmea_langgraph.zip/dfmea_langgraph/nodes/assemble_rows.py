"""
nodes/assemble_rows.py
======================
Joins elements, functions, modes, causes, and ratings into flat DFMEARow
and ifmea_row lists, ready for export.

Reads:  elements, failure_modes, failure_causes, ifmea_interfaces
Writes: dfmea_rows, ifmea_rows
"""

import uuid
from dfmea_state import DFMEAState, DFMEARow


def _uid() -> str:
    return str(uuid.uuid4())[:8]


def assemble_rows(state: DFMEAState) -> dict:
    mode_map = {m["id"]: m for m in state.get("failure_modes", [])}

    # Build element → first function lookup
    elem_fn_map: dict[str, str] = {}
    for elem in state.get("elements", []):
        fns = elem.get("functions", [])
        if fns:
            elem_fn_map[elem["name"]] = fns[0]

    # ── DFMEA rows ────────────────────────────────────────────────────────────
    dfmea_rows: list[DFMEARow] = []

    for cause in state.get("failure_causes", []):
        if not cause.get("selected"):
            continue

        mode         = mode_map.get(cause.get("failure_mode_id", ""), {})
        element_name = mode.get("element", "")
        fn           = elem_fn_map.get(element_name, "")

        # Identify lower element from B-diagram connections for this element
        lower_name = ""
        for conn in state.get("b_connections", []):
            elem_map = {e["key"]: e for e in state.get("elements", [])}
            from_e = elem_map.get(conn.get("from_key", ""), {})
            to_e   = elem_map.get(conn.get("to_key", ""),   {})
            if to_e.get("name") == element_name and from_e.get("level") == "lower":
                lower_name = from_e.get("name", "")
                break

        dfmea_rows.append(DFMEARow(
            id=_uid(),
            element=element_name,
            function=fn,
            failure_mode=mode.get("mode", ""),
            failure_effect=cause.get("failure_effect", ""),
            failure_cause=cause.get("cause", ""),
            noise_category=cause.get("noise_category", ""),
            noise_factor=cause.get("noise_factor", ""),
            prevention_controls=cause.get("prevention_methods", ""),
            detection_controls=cause.get("detection_methods", ""),
            severity=cause.get("severity", 1),
            occurrence=cause.get("occurrence", 1),
            detection=cause.get("detection", 1),
            rpn=cause.get("rpn", 1),
            action_priority=cause.get("action_priority", "L"),
            recommended_action=cause.get("recommended_action", ""),
        ))

    # ── IFMEA rows ────────────────────────────────────────────────────────────
    # Flatten selected causes from all interfaces into export-ready dicts.
    ifmea_rows: list[dict] = []

    for iface in state.get("ifmea_interfaces", []):
        for cause in iface.get("causes", []):
            if not cause.get("selected"):
                continue

            from services.risk_utils import (
                occurrence_from_answer,
                detection_from_answer,
                compute_rpn,
                compute_ap,
            )
            sev = cause.get("severity", 5)
            occ = occurrence_from_answer(cause.get("occurrence_answer", "moderate"))
            det = detection_from_answer(cause.get("detection_answer", "moderate"))
            rpn = compute_rpn(sev, occ, det)
            ap  = compute_ap(rpn, sev)

            ifmea_rows.append({
                # Export columns — map to IFMEA xlsx template fields
                "interface_element1":     iface.get("from_element", ""),
                "interface_element2":     iface.get("to_element", ""),
                "nominal_transfer":       iface.get("nominal_transfer", ""),
                "failure_mode":           cause.get("failure_mode", ""),
                "failure_effect":         cause.get("failure_effect", ""),
                "failure_cause":          cause.get("cause", ""),
                "severity":               sev,
                "current_design_controls": "",
                "prevention_controls":    cause.get("prevention_controls", ""),
                "occurrence":             occ,
                "detection_controls":     cause.get("detection_controls", ""),
                "detection":              det,
                "rpn":                    rpn,
                "action_priority":        ap,
            })

    return {
        "dfmea_rows": dfmea_rows,
        "ifmea_rows": ifmea_rows,
    }
