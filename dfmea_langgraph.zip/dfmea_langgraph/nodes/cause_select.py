"""
nodes/cause_select.py
=====================
Human-in-the-loop pause for cause selection and rating input.

Interrupts and waits for frontend to POST back:
  {
    failure_causes: FailureCause[]   (selected + prevention/detection methods +
                                      occurrence_answer + detection_answer filled)
  }

Reads:  failure_causes
Writes: failure_causes, failure_cause_status = DONE
"""

from langgraph.types import interrupt
from dfmea_state import DFMEAState, TaskStatus


def cause_select(state: DFMEAState) -> dict:
    user_input = interrupt({
        "step":    "cause_select",
        "message": "Select causes and enter prevention/detection methods and ratings.",
        "state":   {"failure_causes": state.get("failure_causes", [])},
    })
    return {
        "failure_causes":       user_input.get("failure_causes", state.get("failure_causes", [])),
        "failure_cause_status": TaskStatus.DONE,
    }
