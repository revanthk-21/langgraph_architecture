"""
services/similarity_utils.py
=============================
Function-connection suggestion logic.
Two strategies — both exposed here so nodes/routers can pick one:
  - suggest_by_llm()       → uses LLM (similarity_llm.py)
  - suggest_by_embeddings() → uses Titan embeddings (similarity.py)
"""

import os
import re
import json
import numpy as np
import requests
from dataclasses import dataclass, field


# ─────────────────────────────────────────────────────────────────────────────
# Shared data model
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class FunctionItem:
    id:          str
    name:        str
    elementName: str


@dataclass
class SuggestResult:
    focus_fn_id: str
    lower:  list[dict] = field(default_factory=list)   # [{id, name, elementName, similarity}]
    higher: list[dict] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# LLM-based suggestion  (from similarity_llm.py)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_index_list(text: str, max_index: int) -> list[int]:
    if not text or "NONE" in text.upper():
        return []
    found = re.findall(r"\b(\d+)\b", text)
    seen, result = set(), []
    for n in found:
        i = int(n) - 1
        if 0 <= i < max_index and i not in seen:
            seen.add(i)
            result.append(i)
    return result


def suggest_for_focus_llm(
    focus_fn: FunctionItem,
    lower_fns: list[FunctionItem],
    higher_fns: list[FunctionItem],
    top_k_lower: int,
    top_k_higher: int,
    llm,
) -> SuggestResult:
    result = SuggestResult(focus_fn_id=focus_fn.id)

    # ── Lower ────────────────────────────────────────────────────────────────
    if lower_fns:
        numbered = "\n".join(
            f"{i+1}. [{fn.elementName}] {fn.name}" for i, fn in enumerate(lower_fns)
        )
        prompt = f"""Focus function: "{focus_fn.name}"

Lower-level functions (numbered):
{numbered}

TASK: Which lower-level functions directly CAUSE or ENABLE the focus function?
A lower function is related if its failure could directly produce a failure mode
in the focus function.

RULES:
- Output ONLY the numbers of related functions, comma-separated
- Maximum {top_k_lower} numbers
- If none are related output exactly: NONE

OUTPUT (numbers only, e.g. "2, 5" or "NONE"):"""

        try:
            raw = llm.generate(prompt, max_tokens=60)
        except Exception:
            raw = "NONE"

        for i in _parse_index_list(raw, len(lower_fns)):
            fn = lower_fns[i]
            result.lower.append({"id": fn.id, "name": fn.name, "elementName": fn.elementName, "similarity": 1.0})

    # ── Higher ───────────────────────────────────────────────────────────────
    if higher_fns:
        numbered = "\n".join(
            f"{i+1}. [{fn.elementName}] {fn.name}" for i, fn in enumerate(higher_fns)
        )
        prompt = f"""Focus function: "{focus_fn.name}"

Higher-level functions (numbered):
{numbered}

TASK: Which higher-level functions are directly AFFECTED when the focus function fails?
A higher function is related if losing the focus function degrades or prevents it.

RULES:
- Output ONLY the numbers of related functions, comma-separated
- Maximum {top_k_higher} numbers
- If none are related output exactly: NONE

OUTPUT (numbers only, e.g. "1, 3" or "NONE"):"""

        try:
            raw = llm.generate(prompt, max_tokens=60)
        except Exception:
            raw = "NONE"

        for i in _parse_index_list(raw, len(higher_fns)):
            fn = higher_fns[i]
            result.higher.append({"id": fn.id, "name": fn.name, "elementName": fn.elementName, "similarity": 1.0})

    return result


def suggest_by_llm(
    lower_functions:  list[FunctionItem],
    focus_functions:  list[FunctionItem],
    higher_functions: list[FunctionItem],
    llm,
    top_k_lower:  int   = 3,
    top_k_higher: int   = 2,
) -> dict[str, dict]:
    """Returns {focus_fn_id: {lower: [...], higher: [...]}}"""
    valid_lower  = [f for f in lower_functions  if f.name.strip()]
    valid_higher = [f for f in higher_functions if f.name.strip()]

    suggestions = {}
    for ff in focus_functions:
        if not ff.name.strip():
            continue
        res = suggest_for_focus_llm(ff, valid_lower, valid_higher, top_k_lower, top_k_higher, llm)
        suggestions[ff.id] = {"lower": res.lower, "higher": res.higher}
    return suggestions


# ─────────────────────────────────────────────────────────────────────────────
# Embedding-based suggestion  (from similarity.py)
# ─────────────────────────────────────────────────────────────────────────────

REGION      = os.environ.get("BEDROCK_REGION", "ap-south-1")
TITAN_MODEL = "amazon.titan-embed-text-v2:0"
TITAN_URL   = f"https://bedrock-runtime.{REGION}.amazonaws.com/model/{TITAN_MODEL}/invoke"
BEDROCK_KEY = os.environ.get("BEDROCK_API_KEY", "")


def _get_embedding(text: str) -> np.ndarray:
    headers = {
        "Authorization": f"Bearer {BEDROCK_KEY}",
        "Content-Type":  "application/json",
    }
    payload = {"inputText": text, "dimensions": 512, "normalize": True}
    resp = requests.post(TITAN_URL, headers=headers, json=payload)
    resp.raise_for_status()
    return np.array(resp.json()["embedding"], dtype=np.float32)


class _EmbeddingCache:
    def __init__(self):
        self._store: dict[str, np.ndarray] = {}

    def get(self, text: str) -> np.ndarray:
        if text not in self._store:
            self._store[text] = _get_embedding(text)
        return self._store[text]


def suggest_by_embeddings(
    lower_functions:  list[FunctionItem],
    focus_functions:  list[FunctionItem],
    higher_functions: list[FunctionItem],
    top_k_lower:  int   = 3,
    top_k_higher: int   = 2,
    threshold:    float = 0.55,
) -> dict[str, dict]:
    """Returns {focus_fn_id: {lower: [...], higher: [...]}}"""
    cache = _EmbeddingCache()

    for fn in [*lower_functions, *focus_functions, *higher_functions]:
        if fn.name.strip():
            cache.get(fn.name)

    suggestions = {}
    for ff in focus_functions:
        if not ff.name.strip():
            continue
        focus_emb = cache.get(ff.name)

        lower_scored = sorted(
            [
                {"id": lf.id, "name": lf.name, "elementName": lf.elementName,
                 "similarity": round(float(np.dot(focus_emb, cache.get(lf.name))), 4)}
                for lf in lower_functions if lf.name.strip()
                if float(np.dot(focus_emb, cache.get(lf.name))) >= threshold
            ],
            key=lambda x: x["similarity"], reverse=True,
        )[:top_k_lower]

        higher_scored = sorted(
            [
                {"id": hf.id, "name": hf.name, "elementName": hf.elementName,
                 "similarity": round(float(np.dot(focus_emb, cache.get(hf.name))), 4)}
                for hf in higher_functions if hf.name.strip()
                if float(np.dot(focus_emb, cache.get(hf.name))) >= threshold
            ],
            key=lambda x: x["similarity"], reverse=True,
        )[:top_k_higher]

        suggestions[ff.id] = {"lower": lower_scored, "higher": higher_scored}

    return suggestions
