"""
services/export_utils.py
========================
Pure xlsx writing logic extracted from export_template.py and export_ifmea_template.py.
Returns a BytesIO buffer — no FastAPI StreamingResponse.
Callers (nodes and routers) wrap it however they need.
"""

import io
import os
import re
from typing import List, Optional, Dict

from openpyxl import load_workbook
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.styles import Alignment


# ─────────────────────────────────────────────────────────────────────────────
# Shared helpers (merged-cell safe)
# ─────────────────────────────────────────────────────────────────────────────

def _cell_in_range(rng, row: int, col: int) -> bool:
    return rng.min_row <= row <= rng.max_row and rng.min_col <= col <= rng.max_col


def _bottom_of_merge(sheet: Worksheet, row: int, col: int) -> int:
    for rng in sheet.merged_cells.ranges:
        if _cell_in_range(rng, row, col):
            return rng.max_row
    return row


def _is_blocked_by_merge(sheet: Worksheet, row: int, col: int) -> bool:
    for rng in sheet.merged_cells.ranges:
        if _cell_in_range(rng, row, col):
            return not (row == rng.min_row and col == rng.min_col)
    return False


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def _last_used_row(sheet: Worksheet, cols: List[int], start_row: int) -> int:
    last = start_row - 1
    for r in range(start_row, sheet.max_row + 1):
        for col in cols:
            if sheet.cell(row=r, column=col).value not in (None, ""):
                last = r
                break
    return last


def _first_writable_row(sheet: Worksheet, cols: List[int], start_row: int) -> int:
    r = start_row
    while True:
        if not any(_is_blocked_by_merge(sheet, r, c) for c in cols):
            return r
        r += 1


def _find_header_row(sheet: Worksheet) -> int:
    for r in range(1, min(sheet.max_row, 80) + 1):
        has_item = has_mode = False
        for c in range(1, sheet.max_column + 1):
            v = sheet.cell(row=r, column=c).value
            if not isinstance(v, str):
                continue
            n = _norm(v)
            if n in {"itemfunction", _norm("item / function"), _norm("item function")}:
                has_item = True
            if n in {"potentialfailuremode", "failuremode"}:
                has_mode = True
        if has_item and has_mode:
            return r
    return 1


# ─────────────────────────────────────────────────────────────────────────────
# DFMEA header aliases
# ─────────────────────────────────────────────────────────────────────────────

DFMEA_HEADER_ALIASES: Dict[str, List[str]] = {
    "item/function": ["item / function", "item/function", "item function", "itemfunction", "function"],
    "requirement": ["requirement", "requirements"],
    "potentialfailuremode": ["potential failure mode", "potentialfailuremode", "failure mode", "failuremode"],
    "potentialeffectsoffailure": ["potential effect(s) of failure", "potential effects of failure", "potentialeffectsoffailure", "failure effect", "effect"],
    "severity": ["severity", "s"],
    "classification": ["classification", "class"],
    "potentialcauses/mechanismsoffailure": ["potential cause(s) / mechanism(s) of failure", "potential causes / mechanisms of failure", "potentialcauses/mechanismsoffailure", "potential causes", "cause", "causes"],
    "currentdesigncontrols": ["current design controls", "currentdesigncontrols", "current controls", "controls", "design controls"],
    "occurrence": ["occurrence", "o"],
    "detection": ["detection", "d"],
    "r.p.n.": ["r.p.n.", "rpn"],
    "recommendedactions": ["recommended actions", "recommendedactions", "actions"],
    "responsibility&targetcompletiondate": ["responsibility & target completion date", "responsibility&targetcompletiondate", "responsibility", "owner&date", "owner & date"],
}


def _match_header_index(sheet: Worksheet, target_key: str, header_row: int, aliases: Dict[str, List[str]]) -> Optional[int]:
    target_norm = _norm(target_key)
    alias_norms = [_norm(a) for a in aliases.get(target_key, [])]
    for r in range(header_row, min(sheet.max_row, header_row + 2) + 1):
        for col in range(1, sheet.max_column + 1):
            val = sheet.cell(row=r, column=col).value
            if not val or not isinstance(val, str):
                continue
            n = _norm(val)
            if n == target_norm or n in alias_norms:
                return col
    return None


def _match_all_header_cols(sheet: Worksheet, key: str, header_row: int, aliases: Dict[str, List[str]], scan_rows: int = 3) -> List[int]:
    wanted = {_norm(key)} | {_norm(a) for a in aliases.get(key, [])}
    cols = []
    for r in range(header_row, min(sheet.max_row, header_row + scan_rows) + 1):
        for c in range(1, sheet.max_column + 1):
            v = sheet.cell(row=r, column=c).value
            if not isinstance(v, str):
                continue
            if _norm(v) in wanted and c not in cols:
                cols.append(c)
    return cols


# ─────────────────────────────────────────────────────────────────────────────
# DFMEA export
# ─────────────────────────────────────────────────────────────────────────────

def export_dfmea_to_buffer(rows: list[dict], template_path: Optional[str] = None) -> io.BytesIO:
    """
    Write DFMEA rows into the xlsx template. Returns a BytesIO buffer.

    Each row dict expected keys (all optional except focus_element):
      focus_element, lower_element, focus_function, failure_mode,
      failure_effect, severity, occurrence, failure_cause,
      prevention_methods, detection_methods, detection, rpn
    """
    path = template_path or os.environ.get("DFMEA_TEMPLATE_PATH", "Template_DFMEA.xlsx")
    wb = load_workbook(path)
    sheet = wb["DFMEA Worksheet"] if "DFMEA Worksheet" in wb.sheetnames else wb.active
    header_row = _find_header_row(sheet)

    columns = {k: _match_header_index(sheet, k, header_row, DFMEA_HEADER_ALIASES)
               for k in DFMEA_HEADER_ALIASES}

    cols_to_write = [c for c in columns.values() if c]
    if not cols_to_write:
        raise ValueError("Could not detect DFMEA table columns in template.")

    header_block_bottom = header_row
    for col in cols_to_write:
        header_block_bottom = max(header_block_bottom, _bottom_of_merge(sheet, header_row, col))
    first_data_row = header_block_bottom + 1

    last_used  = _last_used_row(sheet, cols_to_write, first_data_row)
    write_row  = _first_writable_row(sheet, cols_to_write, max(first_data_row, last_used + 1))
    wrap       = Alignment(wrap_text=True, vertical="top")

    for row in rows:
        write_row = _first_writable_row(sheet, cols_to_write, write_row)

        _w = lambda key, val: (
            sheet.cell(row=write_row, column=columns[key], value=val).__setattr__("alignment", wrap)
            if columns.get(key) and val is not None else None
        )
        _wn = lambda key, val: (
            sheet.cell(row=write_row, column=columns[key], value=val)
            if columns.get(key) and val is not None else None
        )

        col = columns.get("item/function")
        if col:
            sheet.cell(row=write_row, column=col,
                       value=f"{row.get('focus_element','')} - {row.get('lower_element','')}").alignment = wrap

        col = columns.get("requirement")
        if col:
            sheet.cell(row=write_row, column=col, value=row.get("focus_function", "")).alignment = wrap

        col = columns.get("potentialfailuremode")
        if col:
            sheet.cell(row=write_row, column=col, value=row.get("failure_mode", "")).alignment = wrap

        col = columns.get("potentialeffectsoffailure")
        if col:
            sheet.cell(row=write_row, column=col, value=row.get("failure_effect", "")).alignment = wrap

        col = columns.get("severity")
        if col and row.get("severity") is not None:
            sheet.cell(row=write_row, column=col, value=row["severity"])

        col = columns.get("classification")
        if col:
            sheet.cell(row=write_row, column=col, value="")

        col = columns.get("potentialcauses/mechanismsoffailure")
        if col:
            sheet.cell(row=write_row, column=col, value=row.get("failure_cause", "")).alignment = wrap

        col = columns.get("currentdesigncontrols")
        if col:
            parts = []
            if row.get("prevention_methods"):
                parts.append(f"Prevention: {row['prevention_methods']}")
            if row.get("detection_methods"):
                parts.append(f"Detection: {row['detection_methods']}")
            sheet.cell(row=write_row, column=col, value="; ".join(parts)).alignment = wrap

        col = columns.get("occurrence")
        if col and row.get("occurrence") is not None:
            sheet.cell(row=write_row, column=col, value=row["occurrence"])

        col = columns.get("detection")
        if col and row.get("detection") is not None:
            sheet.cell(row=write_row, column=col, value=row["detection"])

        col = columns.get("r.p.n.")
        if col and row.get("rpn") is not None:
            sheet.cell(row=write_row, column=col, value=row["rpn"])

        col = columns.get("recommendedactions")
        if col:
            sheet.cell(row=write_row, column=col, value="")

        col = columns.get("responsibility&targetcompletiondate")
        if col:
            sheet.cell(row=write_row, column=col, value="")

        write_row += 1

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


# ─────────────────────────────────────────────────────────────────────────────
# IFMEA export
# ─────────────────────────────────────────────────────────────────────────────

IFMEA_HEADER_ALIASES: Dict[str, List[str]] = {
    "item/function": ["item / function", "item/function", "item function", "itemfunction"],
    "requirement": ["requirement", "requirements"],
    "potentialfailuremode": ["potential failure mode", "failure mode", "failuremode"],
    "potentialeffectsoffailure": ["potential effect(s) of failure", "potential effects of failure", "failure effect", "effect"],
    "severity": ["severity", "s"],
    "classification": ["classification", "class"],
    "potentialcauses/mechanismsoffailure": ["potential cause(s) / mechanism(s) of failure", "potential causes / mechanisms of failure", "potential causes", "cause", "causes"],
    "currentdesigncontrols": ["current design controls", "current controls", "design controls", "controls"],
    "occurrence": ["occurrence", "o"],
    "detection": ["detection", "d"],
    "r.p.n.": ["r.p.n.", "rpn"],
    "preventive": ["preventive"],
}


def export_ifmea_to_buffer(rows: list[dict], template_path: Optional[str] = None) -> io.BytesIO:
    """
    Write IFMEA rows into the xlsx template. Returns a BytesIO buffer.

    Each row dict expected keys:
      interface_element1, interface_element2, nominal_transfer,
      failure_mode, failure_effect, failure_cause, severity,
      current_design_controls, prevention_controls, occurrence,
      detection_controls, detection, rpn
    """
    path = template_path or os.environ.get("DFMEA_TEMPLATE_PATH", "Template_DFMEA.xlsx")
    wb = load_workbook(path)
    sheet = wb["DFMEA Worksheet"] if "DFMEA Worksheet" in wb.sheetnames else wb.active
    header_row = _find_header_row(sheet)

    item_cols       = _match_all_header_cols(sheet, "item/function",  header_row, IFMEA_HEADER_ALIASES)
    req_cols        = _match_all_header_cols(sheet, "requirement",    header_row, IFMEA_HEADER_ALIASES)
    mode_cols       = _match_all_header_cols(sheet, "potentialfailuremode", header_row, IFMEA_HEADER_ALIASES)
    eff_cols        = _match_all_header_cols(sheet, "potentialeffectsoffailure", header_row, IFMEA_HEADER_ALIASES)
    sev_cols        = _match_all_header_cols(sheet, "severity",       header_row, IFMEA_HEADER_ALIASES)
    cls_cols        = _match_all_header_cols(sheet, "classification", header_row, IFMEA_HEADER_ALIASES)
    cause_cols      = _match_all_header_cols(sheet, "potentialcauses/mechanismsoffailure", header_row, IFMEA_HEADER_ALIASES)
    cdc_cols        = _match_all_header_cols(sheet, "currentdesigncontrols", header_row, IFMEA_HEADER_ALIASES)
    occ_cols        = _match_all_header_cols(sheet, "occurrence",    header_row, IFMEA_HEADER_ALIASES)
    det_cols        = _match_all_header_cols(sheet, "detection",     header_row, IFMEA_HEADER_ALIASES)
    rpn_cols        = _match_all_header_cols(sheet, "r.p.n.",        header_row, IFMEA_HEADER_ALIASES)
    preventive_cols = _match_all_header_cols(sheet, "preventive",    header_row, IFMEA_HEADER_ALIASES)

    col_item     = item_cols[0]       if item_cols        else None
    col_req      = req_cols[0]        if req_cols         else None
    col_mode     = mode_cols[0]       if mode_cols        else None
    col_eff      = eff_cols[0]        if eff_cols         else None
    col_sev      = sev_cols[0]        if sev_cols         else None
    col_cls      = cls_cols[0]        if cls_cols         else None
    col_cause    = cause_cols[0]      if cause_cols       else None
    col_cdc      = cdc_cols[0]        if cdc_cols         else None
    col_occ_main = occ_cols[0]        if len(occ_cols) >= 1 else None
    col_occ_ar   = occ_cols[1]        if len(occ_cols) >= 2 else None
    col_det_main = det_cols[0]        if len(det_cols) >= 1 else None
    col_det_ar   = det_cols[1]        if len(det_cols) >= 2 else None
    col_rpn_main = rpn_cols[0]        if len(rpn_cols) >= 1 else None
    col_rpn_ar   = rpn_cols[1]        if len(rpn_cols) >= 2 else None
    col_prev_ar  = preventive_cols[0] if preventive_cols  else None

    cols_to_check = [c for c in [
        col_item, col_req, col_mode, col_eff, col_sev, col_cls, col_cause, col_cdc,
        col_occ_main, col_det_main, col_rpn_main, col_prev_ar, col_occ_ar, col_det_ar, col_rpn_ar
    ] if c]

    if not cols_to_check:
        raise ValueError("Could not detect DFMEA worksheet table columns.")

    header_block_bottom = header_row
    for c in cols_to_check:
        header_block_bottom = max(header_block_bottom, _bottom_of_merge(sheet, header_row, c))
    first_data_row = header_block_bottom + 1

    last_used = _last_used_row(sheet, cols_to_check, first_data_row)
    write_row = _first_writable_row(sheet, cols_to_check, max(first_data_row, last_used + 1))
    wrap = Alignment(wrap_text=True, vertical="top")

    for r in rows:
        write_row = _first_writable_row(sheet, cols_to_check, write_row)

        if col_item:
            sheet.cell(row=write_row, column=col_item,
                       value=f"({r.get('interface_element1','')} - {r.get('interface_element2','')})").alignment = wrap
        if col_req:
            sheet.cell(row=write_row, column=col_req, value=r.get("nominal_transfer", "")).alignment = wrap
        if col_mode:
            sheet.cell(row=write_row, column=col_mode, value=r.get("failure_mode", "")).alignment = wrap
        if col_eff:
            sheet.cell(row=write_row, column=col_eff, value=r.get("failure_effect", "")).alignment = wrap
        if col_sev and r.get("severity") is not None:
            sheet.cell(row=write_row, column=col_sev, value=r["severity"])
        if col_cls:
            sheet.cell(row=write_row, column=col_cls, value="")
        if col_cause:
            sheet.cell(row=write_row, column=col_cause, value=r.get("failure_cause", "")).alignment = wrap
        if col_cdc:
            sheet.cell(row=write_row, column=col_cdc, value=r.get("current_design_controls", "")).alignment = wrap
        if col_occ_main and r.get("occurrence") is not None:
            sheet.cell(row=write_row, column=col_occ_main, value=r["occurrence"])
        if col_det_main and r.get("detection") is not None:
            sheet.cell(row=write_row, column=col_det_main, value=r["detection"])
        if col_rpn_main and r.get("rpn") is not None:
            sheet.cell(row=write_row, column=col_rpn_main, value=r["rpn"])
        if col_prev_ar:
            sheet.cell(row=write_row, column=col_prev_ar, value=r.get("prevention_controls", "")).alignment = wrap
        if col_occ_ar and r.get("occurrence") is not None:
            sheet.cell(row=write_row, column=col_occ_ar, value=r["occurrence"])
        if col_det_ar:
            sheet.cell(row=write_row, column=col_det_ar, value=r.get("detection_controls", "")).alignment = wrap
        if col_rpn_ar and r.get("rpn") is not None:
            sheet.cell(row=write_row, column=col_rpn_ar, value=r["rpn"])

        write_row += 1

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf
