"""
services/risk_utils.py
======================
Pure risk-rating logic extracted from routers/risk_rating.py and routers/severity.py.
No FastAPI. Called by both the LangGraph nodes and the FastAPI graph_router.
"""

import json
import re

# ── Occurrence table (AIAG-VDA aligned) ──────────────────────────────────────

OCCURRENCE_MAP = {
    "very_high": 9,
    "high":      7,
    "moderate":  5,
    "low":       3,
    "very_low":  2,
    "unlikely":  1,
}

DETECTION_MAP = {
    "unlikely":  9,
    "low":       7,
    "moderate":  5,
    "high":      3,
    "certain":   1,
}

OCCURRENCE_LABELS = {9: "Very High", 7: "High", 5: "Moderate", 3: "Low", 2: "Very Low", 1: "Unlikely"}
DETECTION_LABELS  = {9: "Unlikely",  7: "Low",  5: "Moderate", 3: "High", 1: "Certain"}

OCCURRENCE_OPTIONS = [
    {"value": "very_high", "label": "Very High",  "description": "Almost certain to occur repeatedly",      "rating": 9},
    {"value": "high",      "label": "High",       "description": "Will occur with some regularity",         "rating": 7},
    {"value": "moderate",  "label": "Moderate",   "description": "Occasional occurrence expected",          "rating": 5},
    {"value": "low",       "label": "Low",        "description": "Occurrence is low",                       "rating": 3},
    {"value": "very_low",  "label": "Very Low",   "description": "Occurrence is very low",                  "rating": 2},
    {"value": "unlikely",  "label": "Unlikely",   "description": "Failure excluded or extremely unlikely",  "rating": 1},
]

DETECTION_OPTIONS = [
    {"value": "unlikely",  "label": "Unlikely",  "description": "No method exists or test cannot detect",          "rating": 9},
    {"value": "low",       "label": "Low",       "description": "Method exists but unproven or indirect",          "rating": 7},
    {"value": "moderate",  "label": "Moderate",  "description": "Proven method from comparable product/process",   "rating": 5},
    {"value": "high",      "label": "High",      "description": "Proven method confirmed for this product",        "rating": 3},
    {"value": "certain",   "label": "Certain",   "description": "Automated / continuous detection guaranteed",     "rating": 1},
]

SEVERITY_RUBRIC = """
Severity Rubric (AIAG-VDA aligned):

S=10  Hazardous effect without warning. Safety risk to vehicle occupants or others. Regulatory non-compliance.
S=9   Hazardous effect with warning. Safety risk to vehicle occupants or others. Regulatory non-compliance.
S=8   Very High. Primary vehicle or system function completely lost. Vehicle inoperable. Customer very dissatisfied.
S=7   High. Primary function degraded but still operational. Customer dissatisfied.
S=6   Moderate. Secondary function completely lost. Customer experiences discomfort.
S=5   Moderate. Secondary function degraded. Customer experiences some discomfort.
S=4   Low. Noticeable deterioration — appearance, NVH (noise, vibration, harshness). Most customers notice (>75%).
S=3   Very Low. Minor effect. About half of customers notice (50%).
S=2   Minor. Very minor effect. Very discerning customers notice (<25%).
S=1   None. No discernible effect on vehicle operation, customer, or quality.
""".strip()

OCCURRENCE_RUBRIC = """
Occurrence likelihood scale — pick ONE:
  "very_high" (O=9): Almost certain. Failure mechanism is well-known and frequently seen in field.
  "high"      (O=7): Will occur with some regularity under these conditions.
  "moderate"  (O=5): Occasional occurrence expected. Has happened before on similar systems.
  "low"       (O=3): Unlikely but possible. Seen rarely.
  "very_low"  (O=2): Very unlikely. Near the edge of what the noise factor can cause.
  "unlikely"  (O=1): Failure virtually excluded. Extremely robust against this noise factor.
""".strip()

DETECTION_RUBRIC = """
Detection likelihood scale — pick ONE:
  "unlikely"  (D=9): No test method exists or cannot detect this cause before customer delivery.
  "low"       (D=7): A detection method exists but is unproven or indirect for this cause.
  "moderate"  (D=5): A proven detection method exists from a comparable product.
  "high"      (D=3): Proven detection method confirmed and validated for this specific product.
  "certain"   (D=1): Automated or continuous detection — failure cannot escape to customer.
""".strip()


# ── Pure functions ─────────────────────────────────────────────────────────────

def occurrence_from_answer(answer: str) -> int:
    return OCCURRENCE_MAP.get(answer, 5)


def detection_from_answer(answer: str) -> int:
    return DETECTION_MAP.get(answer, 5)


def compute_rpn(severity: int, occurrence: int, detection: int) -> int:
    return severity * occurrence * detection


def compute_ap(rpn: int, severity: int) -> str:
    if severity >= 9 or rpn >= 200:
        return "H"
    if severity >= 7 or rpn >= 100:
        return "M"
    return "L"


def rate_cause_row(
    severity: int,
    occurrence_answer: str,
    detection_answer: str,
) -> dict:
    """Convert qualitative answers into full risk dict. Used by both node and router."""
    o   = occurrence_from_answer(occurrence_answer)
    d   = detection_from_answer(detection_answer)
    rpn = compute_rpn(severity, o, d)
    ap  = compute_ap(rpn, severity)
    return {
        "occurrence":        o,
        "occurrence_label":  OCCURRENCE_LABELS.get(o, ""),
        "detection":         d,
        "detection_label":   DETECTION_LABELS.get(d, ""),
        "rpn":               rpn,
        "action_priority":   ap,
    }


def _strip_json(text: str) -> str:
    text = re.sub(r"^```(?:json)?\s*", "", text.strip())
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def rate_severity_llm(higher_function: str, failure_effect: str, llm) -> dict:
    """
    LLM-based severity rating. llm must have a .generate(prompt, max_tokens) method.
    Returns dict with severity_rank, matched_rubric_bullet, reason.
    """
    prompt = f"""TASK: Rate the severity of a DFMEA failure effect.

Higher-level function that is affected:
"{higher_function}"

Failure effect (what happens to that higher-level function):
"{failure_effect}"

{SEVERITY_RUBRIC}

INSTRUCTIONS:
1. Identify which rubric level best matches the failure effect on the higher-level function.
2. Consider the worst credible impact, not the average case.
3. Output ONLY valid JSON — no preamble, no markdown fences.

OUTPUT FORMAT:
{{
  "severity_rank": <integer 1-10>,
  "matched_rubric_bullet": "<copy the matching rubric line exactly>",
  "reason": "<one sentence explaining why this rank applies to this specific effect>"
}}
"""
    raw = llm.generate(prompt, max_tokens=300)
    raw = _strip_json(raw)
    try:
        result = json.loads(raw)
        result["severity_rank"] = max(1, min(10, int(result.get("severity_rank", 5))))
        return result
    except Exception:
        m = re.search(r'"severity_rank"\s*:\s*(\d+)', raw)
        rank = int(m.group(1)) if m else 5
        return {
            "severity_rank":        max(1, min(10, rank)),
            "matched_rubric_bullet": "Could not parse rubric match",
            "reason":                raw[:200],
        }


def rate_cause_auto_llm(
    cause_id: str,
    cause: str,
    noise_factor: str,
    noise_category: str,
    failure_mode: str,
    focus_function: str,
    focus_element: str,
    lower_element: str,
    lower_function: str,
    prevention_methods: str,
    detection_methods: str,
    llm,
) -> dict:
    """
    LLM-based auto occurrence/detection rating.
    Mirrors routers/auto_rating.py logic. Returns dict ready to merge into a FailureCause.
    """
    VALID_O = set(OCCURRENCE_MAP.keys())
    VALID_D = set(DETECTION_MAP.keys())

    prevention = prevention_methods.strip() or "None specified"
    detection  = detection_methods.strip()  or "None specified"

    prompt = f"""You are a senior DFMEA engineer. Assign Occurrence and Detection ratings for this failure cause.

CONTEXT
-------
Focus element   : {focus_element}
Focus function  : {focus_function}
Failure mode    : {failure_mode}
Lower element   : {lower_element}
Lower function  : {lower_function}
Failure cause   : {cause}
Noise factor    : {noise_factor} ({noise_category})
Prevention ctrl : {prevention}
Detection ctrl  : {detection}

OCCURRENCE RUBRIC
-----------------
{OCCURRENCE_RUBRIC}

DETECTION RUBRIC
----------------
{DETECTION_RUBRIC}

TASK
----
1. Assess how likely this cause will occur given the noise factor and prevention controls.
2. Assess how likely the detection controls will catch this cause before it reaches the customer.
3. Give a one-sentence justification for each.

Output ONLY valid JSON, no markdown:
{{
  "occurrence_answer": "<one of the occurrence keys>",
  "detection_answer":  "<one of the detection keys>",
  "occurrence_reasoning": "<one sentence>",
  "detection_reasoning":  "<one sentence>"
}}"""

    raw = llm.generate(prompt, max_tokens=250)
    raw = _strip_json(raw)

    try:
        data = json.loads(raw)
    except Exception:
        data = {}
        for key in ("occurrence_answer", "detection_answer",
                    "occurrence_reasoning", "detection_reasoning"):
            m = re.search(rf'"{key}"\s*:\s*"([^"]+)"', raw)
            if m:
                data[key] = m.group(1)

    o_ans = data.get("occurrence_answer", "moderate")
    d_ans = data.get("detection_answer",  "moderate")
    if o_ans not in VALID_O:
        o_ans = "moderate"
    if d_ans not in VALID_D:
        d_ans = "moderate"

    o   = OCCURRENCE_MAP[o_ans]
    d   = DETECTION_MAP[d_ans]
    rpn = o * d  # severity not available here; caller multiplies if needed

    reasoning = (
        f"O: {data.get('occurrence_reasoning', '—')} "
        f"| D: {data.get('detection_reasoning', '—')}"
    )

    return {
        "cause_id":          cause_id,
        "occurrence_answer": o_ans,
        "detection_answer":  d_ans,
        "occurrence":        o,
        "detection":         d,
        "reasoning":         reasoning,
    }
