"""
services/ifmea_utils.py
=======================
Pure IFMEA generation logic extracted from routers/ifmea.py.
No FastAPI. Called by nodes/ifmea_generate.py and the FastAPI graph_router.
"""

import json
import re
from dataclasses import dataclass

CONN_DESCRIPTIONS = {
    "P": "Physical connection (mechanical joint, fastener, spline, bearing, weld, press fit)",
    "E": "Energy transfer (torque coupling, electrical conductor, hydraulic line, thermal path)",
    "I": "Information transfer (CAN/LIN bus, sensor signal, RF link, digital protocol)",
    "M": "Material transfer (fluid line, coolant circuit, exhaust path, lubrication circuit)",
}


def _strip_json(text: str) -> str:
    text = re.sub(r"^```(?:json)?\s*", "", text.strip())
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _parse_bullet(text: str) -> str:
    return text.strip("–•- \n").strip()


# ── Interface Causes ──────────────────────────────────────────────────────────

def generate_interface_causes(
    from_element: str,
    to_element: str,
    connection_type: str,
    nominal_transfer: str,
    dfmea_failure_mode: str,
    focus_function: str,
    noise_factors: dict[str, list[str]],
    llm,
) -> list[dict]:
    """
    For one (interface × dfmea_failure_mode), generate causes per noise factor.
    Returns list of {cause, noise_category, noise_factor}.
    """
    conn_desc = CONN_DESCRIPTIONS.get(connection_type, connection_type)
    causes = []

    for category, factors in noise_factors.items():
        for factor in factors:
            if not factor.strip():
                continue

            prompt = f"""TASK: Generate an Interface Failure Cause.

CONTEXT
-------
Interface FROM  : {from_element}
Interface TO    : {to_element}
Connection type : {conn_desc}
What is transferred: {nominal_transfer}
Noise factor    : {category}: {factor}

DFMEA failure mode being caused: "{dfmea_failure_mode}"

Your job: explain how the INTERFACE MECHANISM itself degrades under this noise
factor and produces the failure mode above in the connected system.

WHAT AN INTERFACE CAUSE IS
--------------------------
A degradation in the interface mechanism — connector, coupling, joint, cable,
pipe, seal, or protocol layer. NOT a failure inside {from_element} or {to_element} themselves.

Examples by connection type:
  P: fretting corrosion at spline contact reduces torque transfer capacity
  E: increased contact resistance at terminal reduces conducted power
  I: EMI bit-error rate increase corrupts sensor signal value
  M: filter clogging from particulate reduces fluid flow rate

RULES
-----
- Cause must be IN the interface mechanism, triggered by: {factor}
- Must lead to: "{dfmea_failure_mode}"
- Do NOT describe failure inside {from_element} or {to_element}
- One sentence. Specific and physically measurable.

OUTPUT: One cause sentence, or exactly NONE if not realistic.
"""
            raw = llm.generate(prompt, max_tokens=200).strip()
            if not raw or raw.upper() == "NONE":
                continue
            line = next((l for l in raw.split("\n") if l.strip()), raw)
            causes.append({
                "cause":          _parse_bullet(line),
                "noise_category": category,
                "noise_factor":   factor,
            })

    return causes


def generate_interface_causes_bulk(
    from_element: str,
    to_element: str,
    connection_type: str,
    nominal_transfer: str,
    focus_function: str,
    dfmea_failure_modes: list[str],
    noise_factors: dict[str, list[str]],
    llm,
) -> list[dict]:
    """
    Generate causes for each failure_mode in dfmea_failure_modes.
    Returns list of {failure_mode, causes[]}.
    """
    results = []
    for mode in dfmea_failure_modes:
        causes = generate_interface_causes(
            from_element=from_element,
            to_element=to_element,
            connection_type=connection_type,
            nominal_transfer=nominal_transfer,
            dfmea_failure_mode=mode,
            focus_function=focus_function,
            noise_factors=noise_factors,
            llm=llm,
        )
        results.append({"failure_mode": mode, "causes": causes})
    return results


# ── Interface Effects ──────────────────────────────────────────────────────────

def generate_interface_effect(
    from_element: str,
    to_element: str,
    connection_type: str,
    nominal_transfer: str,
    failure_mode: str,
    interface_cause: str,
    higher_element_functions: list[str],
    llm,
) -> str:
    """Returns failure effect string for one interface row."""
    conn_desc = CONN_DESCRIPTIONS.get(connection_type, connection_type)

    if higher_element_functions:
        fns_text = "\n".join(f"  - {fn}" for fn in higher_element_functions)
        effect_instruction = f"""The higher-level element has these functions:
{fns_text}

State which of these functions is degraded or lost because the interface
cause prevents correct transfer. Name the specific function and describe
the impact in one sentence."""
    else:
        effect_instruction = (
            "Describe which higher-level function is degraded or lost "
            "because the interface cause prevents correct transfer. One sentence."
        )

    prompt = f"""TASK: Generate the failure effect on the higher-level function.

Interface FROM  : {from_element}
Interface TO    : {to_element}
Connection type : {conn_desc}
Transferred     : {nominal_transfer}
Failure mode    : "{failure_mode}"
Interface cause : "{interface_cause}"

{effect_instruction}

RULES:
- ONE sentence only
- Name the specific higher-level function affected
- Describe functional impact, not just "it fails"

OUTPUT: Valid JSON only, no markdown.
{{"failure_effect": "<one sentence naming the higher function and its impact>"}}
"""
    raw = llm.generate(prompt, max_tokens=200)
    try:
        result = json.loads(_strip_json(raw))
        return result.get("failure_effect", raw[:200].strip())
    except Exception:
        return raw[:200].strip()


# ── Interface Severity ──────────────────────────────────────────────────────────

SEVERITY_RUBRIC = """
S=10 Hazardous without warning. Safety risk.
S=9  Hazardous with warning. Safety risk.
S=8  Primary vehicle function completely lost.
S=7  Primary function degraded, partially operational.
S=6  Secondary function completely lost.
S=5  Secondary function degraded.
S=4  Noticeable NVH/appearance/performance issue.
S=3  Minor effect, ~50% customers notice.
S=2  Minor. <25% customers notice.
S=1  No discernible effect.
""".strip()


def rate_interface_severity(
    to_element: str,
    failure_effect: str,
    higher_element_functions: list[str],
    llm,
) -> dict:
    """Returns {severity_rank, reason} for one interface row."""
    if not failure_effect.strip():
        return {"severity_rank": 5, "reason": "No effect provided"}

    higher_ctx = ""
    if higher_element_functions:
        higher_ctx = f"\nHigher-level functions: {', '.join(higher_element_functions)}"

    prompt = f"""Rate severity of this interface failure effect on the higher-level function.

Higher element: {to_element}{higher_ctx}
Failure effect: "{failure_effect}"

{SEVERITY_RUBRIC}

Output ONLY valid JSON, no markdown.
{{"severity_rank": <1-10>, "reason": "<one sentence>"}}
"""
    raw = llm.generate(prompt, max_tokens=150)
    try:
        parsed = json.loads(_strip_json(raw))
        rank = max(1, min(10, int(parsed.get("severity_rank", 5))))
        return {"severity_rank": rank, "reason": parsed.get("reason", "")}
    except Exception:
        m = re.search(r'"severity_rank"\s*:\s*(\d+)', raw)
        return {
            "severity_rank": int(m.group(1)) if m else 5,
            "reason": raw[:150],
        }
