"""
services/generation_utils.py
=============================
Pure LLM generation logic for failure modes, causes, and effects.
Extracted from failure_modes.py, failure_causes.py, failure_effects.py.
No FastAPI. Called by nodes and routers alike.
"""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _parse_bullets(text: str) -> list[str]:
    lines = [l.strip("–•- ").strip() for l in text.split("\n")]
    return [l for l in lines if len(l) > 5 and l.upper() != "NONE"]


def _parse_bullet(text: str) -> str:
    return text.strip("–•- ").strip()


# ── Failure Modes ─────────────────────────────────────────────────────────────

def generate_failure_modes(
    focus_function_name: str,
    focus_element_name:  str,
    llm,
) -> list[str]:
    """
    Generate 4-archetype failure modes for a focus element × function.
    Returns list of mode strings.
    """
    prompt = f"""TASK: Generate failure modes for the focus element function.

Focus element: {focus_element_name}
Focus element function: {focus_function_name}

Rules:
- Consider all 4 archetypes:
  1. Function not happening (complete loss)
  2. Function happening partially or too slowly (degraded)
  3. Function happening incorrectly or excessively (wrong output)
  4. Function happening intermittently (random dropout)
- Only return technically realistic cases — skip archetypes with no plausible mode
- Do NOT include causes or effects of failure
- Each failure mode must be ONE sentence describing HOW the function fails

OUTPUT RULES:
- Output bullet points only
- If no realistic failure mode exists, output exactly: NONE
OUTPUT FORMAT:
- <failure mode sentence>
"""
    raw = llm.generate(prompt, max_tokens=800)
    return _parse_bullets(raw)


# ── Failure Causes ─────────────────────────────────────────────────────────────

def generate_causes_for_mode(
    focus_element:    str,
    focus_function:   str,
    failure_mode:     str,
    lower_element:    str,
    lower_function:   str,
    noise_factors:    dict[str, list[str]],   # {category: [factors]}
    llm,
) -> list[dict]:
    """
    Generate one cause per noise factor for the given failure mode + lower element.
    Returns list of {cause, noise_category, noise_factor}.
    """
    causes = []

    for category, factors in noise_factors.items():
        for factor in factors:
            if not factor.strip():
                continue

            prompt = f"""TASK: Generate Failure Cause

Lower-level element: {lower_element}
Lower-level function: {lower_function}
Focus element: {focus_element}
Focus function: {focus_function}
Failure mode: "{failure_mode}"
Noise factor: {category}: {factor}

Rules:
- Cause must originate in the lower-level element/function
- The cause MUST be triggered by the given noise factor
- Must be specific, measurable, and physically/electrically grounded
- Do NOT include effects or restate the failure mode
- ONLY RETURN FAILURE CAUSE IF THE NOISE FACTOR CAN REALISTICALLY AFFECT THE LOWER LEVEL ELEMENT AND ITS FUNCTION

OUTPUT RULES:
- If NO realistic cause exists, output exactly: NONE
- Otherwise output exactly 1 bullet point with one failure cause
OUTPUT FORMAT:
- <failure cause sentence>
"""
            raw = llm.generate(prompt, max_tokens=300).strip()
            if raw and raw.upper() != "NONE":
                line = next((l for l in raw.split("\n") if l.strip()), raw)
                causes.append({
                    "cause":          _parse_bullet(line),
                    "noise_category": category,
                    "noise_factor":   factor,
                })

    return causes


def generate_causes_bulk(
    focus_element:     str,
    focus_function:    str,
    failure_modes:     list[str],
    lower_connections: list[dict],   # [{lower_element, lower_function}]
    noise_factors:     dict[str, list[str]],
    llm,
) -> list[dict]:
    """
    Generate causes for all combinations of failure_modes × lower_connections.
    Returns list of {failure_mode, lower_element, lower_function, causes[]}.
    """
    results = []
    for mode in failure_modes:
        for conn in lower_connections:
            causes = generate_causes_for_mode(
                focus_element=focus_element,
                focus_function=focus_function,
                failure_mode=mode,
                lower_element=conn["lower_element"],
                lower_function=conn["lower_function"],
                noise_factors=noise_factors,
                llm=llm,
            )
            results.append({
                "failure_mode":   mode,
                "lower_element":  conn["lower_element"],
                "lower_function": conn["lower_function"],
                "causes":         causes,
            })
    return results


# ── Failure Effects ────────────────────────────────────────────────────────────

def generate_effect(
    focus_element:   str,
    focus_function:  str,
    failure_mode:    str,
    higher_element:  str,
    higher_function: str,
    llm,
) -> str:
    """
    Generate a single failure effect sentence for one (mode, higher_element) pair.
    """
    prompt = f"""TASK: Generate Failure Effect

Higher-level element: {higher_element}
Higher-level function: {higher_function}
Focus element: {focus_element}
Focus element failure mode: "{failure_mode}"

DEFINITION:
A failure effect describes the loss or degradation of the higher-level function
caused by the focus element failure mode.

REQUIREMENTS:
- The effect MUST describe the impact on the higher-level function only
- Do NOT include the cause or focus element behavior
- The effect MUST be ONE sentence
- Be specific — avoid generic phrases like "system does not work"

OUTPUT FORMAT:
<failure effect sentence>
"""
    return llm.generate(prompt, max_tokens=200).strip()


def generate_effects_bulk(
    rows: list[dict],   # each: {focus_element, focus_function, failure_mode,
                        #        higher_element, higher_function, row_id}
    llm,
) -> list[dict]:
    """
    Generate effects for multiple rows. Returns list of {row_id, failure_effect}.
    """
    results = []
    for row in rows:
        effect = generate_effect(
            focus_element=row["focus_element"],
            focus_function=row["focus_function"],
            failure_mode=row["failure_mode"],
            higher_element=row["higher_element"],
            higher_function=row["higher_function"],
            llm=llm,
        )
        results.append({"row_id": row.get("row_id"), "failure_effect": effect})
    return results
