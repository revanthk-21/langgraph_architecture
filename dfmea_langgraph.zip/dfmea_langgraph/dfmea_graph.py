"""
dfmea_graph.py
==============
LangGraph pipeline for the DFMEA Generator.

Graph topology
--------------
START → route_import
          ├── Case 2/3 → parse_node → b_diagram_checkpoint
          └── Case 1   →              b_diagram_checkpoint
                                           │
                                    failure_mode_node
                                           │
                                      mode_select  ← interrupt
                                           │
                                    failure_cause_node
                                           │
                                      cause_select  ← interrupt
                                           │
                                    risk_rating_node
                                           │
                                    ifmea_generate
                                           │
                                      ifmea_select  ← interrupt
                                           │
                                     assemble_rows
                                           │
                                      export_node
                                           │
                                          END
"""

from __future__ import annotations
from typing import Any

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

from dfmea_state import DFMEAState, ImportCase, initial_state

# ── Node imports (one per file in nodes/) ────────────────────────────────────
from nodes.parse_node    import parse_node
from nodes.b_diagram     import b_diagram_checkpoint
from nodes.failure_mode  import failure_mode_node
from nodes.mode_select   import mode_select
from nodes.failure_cause import failure_cause_node
from nodes.cause_select  import cause_select
from nodes.risk_rating   import risk_rating_node
from nodes.ifmea_generate import ifmea_generate
from nodes.ifmea_select  import ifmea_select
from nodes.assemble_rows import assemble_rows
from nodes.export_node   import export_node


# ── Conditional entry edge ────────────────────────────────────────────────────

def route_import(state: DFMEAState) -> str:
    if state.get("import_case") in (ImportCase.NEW_ENVIRONMENT, ImportCase.DESIGN_CHANGE):
        return "parse_node"
    return "b_diagram_checkpoint"


# ── Graph construction ────────────────────────────────────────────────────────

def build_graph(checkpointer=None):
    """
    Build and compile the DFMEA StateGraph.

    Parameters
    ----------
    checkpointer : BaseCheckpointSaver, optional
        Defaults to MemorySaver (in-process).
        For production swap in PostgresSaver or RedisSaver.

    Returns
    -------
    CompiledGraph

    Usage
    -----
    graph  = build_graph()
    config = {"configurable": {"thread_id": session_id}}

    # First call — runs until first interrupt (b_diagram_checkpoint)
    result = graph.invoke(initial_state(...), config)

    # Resume after user fills in data
    graph.update_state(config, {"elements": [...], "b_connections": [...]})
    result = graph.invoke(Command(resume={}), config)
    """
    if checkpointer is None:
        checkpointer = MemorySaver()

    builder = StateGraph(DFMEAState)

    # ── Nodes ─────────────────────────────────────────────────────────────────
    builder.add_node("parse_node",           parse_node)
    builder.add_node("b_diagram_checkpoint", b_diagram_checkpoint)
    builder.add_node("failure_mode_node",    failure_mode_node)
    builder.add_node("mode_select",          mode_select)
    builder.add_node("failure_cause_node",   failure_cause_node)
    builder.add_node("cause_select",         cause_select)
    builder.add_node("risk_rating_node",     risk_rating_node)
    builder.add_node("ifmea_generate",       ifmea_generate)
    builder.add_node("ifmea_select",         ifmea_select)
    builder.add_node("assemble_rows",        assemble_rows)
    builder.add_node("export_node",          export_node)

    # ── Edges ─────────────────────────────────────────────────────────────────
    builder.add_conditional_edges(
        START,
        route_import,
        {
            "parse_node":           "parse_node",
            "b_diagram_checkpoint": "b_diagram_checkpoint",
        },
    )
    builder.add_edge("parse_node",           "b_diagram_checkpoint")
    builder.add_edge("b_diagram_checkpoint", "failure_mode_node")
    builder.add_edge("failure_mode_node",    "mode_select")
    builder.add_edge("mode_select",          "failure_cause_node")
    builder.add_edge("failure_cause_node",   "cause_select")
    builder.add_edge("cause_select",         "risk_rating_node")
    builder.add_edge("risk_rating_node",     "ifmea_generate")
    builder.add_edge("ifmea_generate",       "ifmea_select")
    builder.add_edge("ifmea_select",         "assemble_rows")
    builder.add_edge("assemble_rows",        "export_node")
    builder.add_edge("export_node",          END)

    return builder.compile(checkpointer=checkpointer)


# ── Singleton + helpers ───────────────────────────────────────────────────────

def get_graph() -> Any:
    """Singleton for FastAPI DI. Swap MemorySaver for PostgresSaver in production."""
    if not hasattr(get_graph, "_instance"):
        get_graph._instance = build_graph()
    return get_graph._instance


def thread_config(session_id: str) -> dict:
    return {"configurable": {"thread_id": session_id}}


def get_current_interrupt(graph, session_id: str) -> dict | None:
    """Return interrupt payload if graph is paused, else None."""
    config = thread_config(session_id)
    state  = graph.get_state(config)
    if state.next:
        return {"paused_at": list(state.next), "state": state.values}
    return None
