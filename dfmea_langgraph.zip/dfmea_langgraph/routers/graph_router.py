"""
routers/graph_router.py
=======================
FastAPI router that:
  1. Drives the LangGraph pipeline (/invoke, /resume, /status, /stream)
  2. Exposes all original REST endpoints (unchanged API surface for the frontend)
     so the wizard can still call them directly for on-demand generation
     outside the graph flow (e.g. regenerate a single failure mode).

All original request/response models are preserved exactly.
"""

import io
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional
from langgraph.types import Command

from dfmea_graph import get_graph, thread_config, get_current_interrupt
from dfmea_state import initial_state, ImportCase
from llm_client import llm

# ── Services ──────────────────────────────────────────────────────────────────
from services.generation_utils import (
    generate_failure_modes,
    generate_causes_for_mode,
    generate_causes_bulk,
    generate_effect,
    generate_effects_bulk,
)
from services.risk_utils import (
    rate_cause_row,
    rate_severity_llm,
    rate_cause_auto_llm,
    OCCURRENCE_OPTIONS,
    DETECTION_OPTIONS,
)
from services.ifmea_utils import (
    generate_interface_causes_bulk,
    generate_interface_effect,
    rate_interface_severity,
)
from services.similarity_utils import suggest_by_llm, suggest_by_embeddings, FunctionItem
from services.export_utils import export_dfmea_to_buffer, export_ifmea_to_buffer

# Import parse (still needs the universal parser directly)
import tempfile, shutil
from pathlib import Path
from dfmea_universal_parser import parse_dfmea_file, apply_consolidation

router = APIRouter(prefix="/api/dfmea")


# ═════════════════════════════════════════════════════════════════════════════
# 1. GRAPH CONTROL ENDPOINTS
# ═════════════════════════════════════════════════════════════════════════════

class InvokeRequest(BaseModel):
    session_id:   str
    import_case:  str = "case1"
    project_name: str = "Untitled"


@router.post("/invoke")
def invoke(req: InvokeRequest):
    """Start a new DFMEA session. Runs until the first interrupt (B-Diagram)."""
    graph  = get_graph()
    config = thread_config(req.session_id)
    state  = initial_state(req.session_id, ImportCase(req.import_case), req.project_name)
    result = graph.invoke(state, config)
    return {"session_id": req.session_id, "paused_at": list(graph.get_state(config).next), "state": result}


@router.post("/resume")
def resume(session_id: str, update: dict):
    """
    Resume after a human-in-the-loop interrupt.
    Call graph.update_state() with the user's data, then resume.
    """
    graph  = get_graph()
    config = thread_config(session_id)
    if update:
        graph.update_state(config, update)
    result = graph.invoke(Command(resume={}), config)
    current = get_current_interrupt(graph, session_id)
    return {
        "session_id": session_id,
        "paused_at":  current["paused_at"] if current else [],
        "done":       current is None,
        "state":      result,
    }


@router.get("/status")
def status(session_id: str):
    """Return current graph state and which node it's paused at."""
    graph  = get_graph()
    config = thread_config(session_id)
    state  = graph.get_state(config)
    return {
        "session_id": session_id,
        "paused_at":  list(state.next) if state.next else [],
        "done":       not bool(state.next),
        "values":     state.values,
    }


# ═════════════════════════════════════════════════════════════════════════════
# 2. FAILURE MODES  (from failure_modes.py)
# ═════════════════════════════════════════════════════════════════════════════

class FailureModesRequest(BaseModel):
    focus_function_name: str
    focus_element_name:  str


@router.post("/failure-modes")
def failure_modes_endpoint(req: FailureModesRequest):
    modes = generate_failure_modes(req.focus_function_name, req.focus_element_name, llm)
    return {"failure_modes": modes}


# ═════════════════════════════════════════════════════════════════════════════
# 3. FAILURE CAUSES  (from failure_causes.py)
# ═════════════════════════════════════════════════════════════════════════════

class CauseRequest(BaseModel):
    focus_element:   str
    focus_function:  str
    failure_mode:    str
    lower_element:   str
    lower_function:  str
    noise_factors:   dict[str, list[str]]


class BulkCausesRequest(BaseModel):
    focus_element:     str
    focus_function:    str
    failure_modes:     list[str]
    lower_connections: list[dict]
    noise_factors:     dict[str, list[str]]


@router.post("/failure-causes")
def failure_causes_endpoint(req: CauseRequest):
    causes = generate_causes_for_mode(
        req.focus_element, req.focus_function, req.failure_mode,
        req.lower_element, req.lower_function, req.noise_factors, llm,
    )
    return {"causes": causes}


@router.post("/failure-causes/bulk")
def failure_causes_bulk(req: BulkCausesRequest):
    results = generate_causes_bulk(
        req.focus_element, req.focus_function,
        req.failure_modes, req.lower_connections, req.noise_factors, llm,
    )
    return {"groups": results}


# ═════════════════════════════════════════════════════════════════════════════
# 4. FAILURE EFFECTS  (from failure_effects.py)
# ═════════════════════════════════════════════════════════════════════════════

class EffectRequest(BaseModel):
    focus_element:   str
    focus_function:  str
    failure_mode:    str
    higher_element:  str
    higher_function: str


class EffectsBulkRequest(BaseModel):
    rows: list[dict]


@router.post("/failure-effects")
def failure_effects_endpoint(req: EffectRequest):
    effect = generate_effect(
        req.focus_element, req.focus_function, req.failure_mode,
        req.higher_element, req.higher_function, llm,
    )
    return {"failure_effect": effect}


@router.post("/failure-effects/bulk")
def failure_effects_bulk(req: EffectsBulkRequest):
    results = generate_effects_bulk(req.rows, llm)
    return {"results": results}


# ═════════════════════════════════════════════════════════════════════════════
# 5. RISK RATING  (from risk_rating.py)
# ═════════════════════════════════════════════════════════════════════════════

class RatingRequest(BaseModel):
    severity:           int
    occurrence_answer:  str
    detection_answer:   str
    prevention_methods: list[str]
    detection_methods:  list[str]


class BulkRatingRow(BaseModel):
    row_id:             str
    severity:           int
    occurrence_answer:  str
    detection_answer:   str
    prevention_methods: list[str]
    detection_methods:  list[str]


class BulkRatingRequest(BaseModel):
    rows: list[BulkRatingRow]


@router.post("/risk-rating")
def risk_rating_endpoint(req: RatingRequest):
    result = rate_cause_row(req.severity, req.occurrence_answer, req.detection_answer)
    return {**result, "prevention_methods": req.prevention_methods, "detection_methods": req.detection_methods}


@router.post("/risk-rating/bulk")
def risk_rating_bulk(req: BulkRatingRequest):
    results = []
    for row in req.rows:
        r = rate_cause_row(row.severity, row.occurrence_answer, row.detection_answer)
        results.append({"row_id": row.row_id, **r,
                        "prevention_methods": row.prevention_methods,
                        "detection_methods": row.detection_methods})
    return {"results": results}


@router.get("/occurrence-options")
def occurrence_options():
    return {"options": OCCURRENCE_OPTIONS}


@router.get("/detection-options")
def detection_options():
    return {"options": DETECTION_OPTIONS}


# ═════════════════════════════════════════════════════════════════════════════
# 6. SEVERITY  (from severity.py)
# ═════════════════════════════════════════════════════════════════════════════

class SeverityRow(BaseModel):
    row_id:          str
    higher_function: str
    failure_effect:  str


class BulkSeverityRequest(BaseModel):
    rows: list[SeverityRow]


@router.post("/severity-rate/bulk")
def severity_rate_bulk(req: BulkSeverityRequest):
    results = []
    for row in req.rows:
        if not row.failure_effect.strip() or not row.higher_function.strip():
            results.append({"row_id": row.row_id, "severity_rank": 5,
                            "matched_rubric_bullet": "No effect", "reason": "Empty input"})
            continue
        rated = rate_severity_llm(row.higher_function, row.failure_effect, llm)
        results.append({"row_id": row.row_id, **rated})
    return {"results": results}


# ═════════════════════════════════════════════════════════════════════════════
# 7. AUTO RATING  (from routers_auto_rating.py)
# ═════════════════════════════════════════════════════════════════════════════

class CauseRatingRequest(BaseModel):
    cause_id:           str
    cause:              str
    noise_factor:       str
    noise_category:     str
    failure_mode:       str
    focus_function:     str
    focus_element:      str
    lower_element:      str
    lower_function:     str
    prevention_methods: str = ""
    detection_methods:  str = ""


class BulkAutoRatingRequest(BaseModel):
    causes: list[CauseRatingRequest]


@router.post("/auto-rating/bulk")
def auto_rating_bulk(req: BulkAutoRatingRequest):
    results = []
    for cause in req.causes:
        try:
            result = rate_cause_auto_llm(
                cause_id=cause.cause_id, cause=cause.cause,
                noise_factor=cause.noise_factor, noise_category=cause.noise_category,
                failure_mode=cause.failure_mode, focus_function=cause.focus_function,
                focus_element=cause.focus_element, lower_element=cause.lower_element,
                lower_function=cause.lower_function,
                prevention_methods=cause.prevention_methods,
                detection_methods=cause.detection_methods,
                llm=llm,
            )
            results.append(result)
        except Exception as e:
            results.append({
                "cause_id": cause.cause_id, "occurrence_answer": "moderate",
                "detection_answer": "moderate", "occurrence": 5, "detection": 5,
                "reasoning": f"Auto-rating failed: {str(e)[:80]}",
            })
    return {"results": results}


# ═════════════════════════════════════════════════════════════════════════════
# 8. IFMEA  (from routers_ifmea.py)
# ═════════════════════════════════════════════════════════════════════════════

class InterfaceCauseBulkRequest(BaseModel):
    from_element:        str
    to_element:          str
    connection_type:     str
    nominal_transfer:    str
    focus_function:      str
    dfmea_failure_modes: list[str]
    noise_factors:       dict[str, list[str]]


class InterfaceEffectRow(BaseModel):
    row_id:                   str
    from_element:             str
    to_element:               str
    connection_type:          str
    nominal_transfer:         str
    failure_mode:             str
    interface_cause:          str
    higher_element_functions: list[str] = []


class InterfaceEffectsBulkRequest(BaseModel):
    rows: list[InterfaceEffectRow]


class InterfaceSeverityRow(BaseModel):
    row_id:                   str
    to_element:               str
    failure_effect:           str
    higher_element_functions: list[str] = []


class InterfaceSeverityBulkRequest(BaseModel):
    rows: list[InterfaceSeverityRow]


@router.post("/interface-causes/bulk")
def interface_causes_bulk(req: InterfaceCauseBulkRequest):
    results = generate_interface_causes_bulk(
        from_element=req.from_element, to_element=req.to_element,
        connection_type=req.connection_type, nominal_transfer=req.nominal_transfer,
        focus_function=req.focus_function, dfmea_failure_modes=req.dfmea_failure_modes,
        noise_factors=req.noise_factors, llm=llm,
    )
    return {"groups": results}


@router.post("/interface-effects/bulk")
def interface_effects_bulk(req: InterfaceEffectsBulkRequest):
    results = []
    for row in req.rows:
        effect = generate_interface_effect(
            from_element=row.from_element, to_element=row.to_element,
            connection_type=row.connection_type, nominal_transfer=row.nominal_transfer,
            failure_mode=row.failure_mode, interface_cause=row.interface_cause,
            higher_element_functions=row.higher_element_functions, llm=llm,
        )
        results.append({"row_id": row.row_id, "failure_effect": effect})
    return {"results": results}


@router.post("/interface-severity/bulk")
def interface_severity_bulk(req: InterfaceSeverityBulkRequest):
    results = []
    for row in req.rows:
        rated = rate_interface_severity(
            to_element=row.to_element, failure_effect=row.failure_effect,
            higher_element_functions=row.higher_element_functions, llm=llm,
        )
        results.append({"row_id": row.row_id, **rated})
    return {"results": results}


# ═════════════════════════════════════════════════════════════════════════════
# 9. SIMILARITY  (from similarity_llm.py / similarity.py)
# ═════════════════════════════════════════════════════════════════════════════

class FunctionItemModel(BaseModel):
    id:          str
    name:        str
    elementName: str


class SuggestRequest(BaseModel):
    lower_functions:  list[FunctionItemModel]
    focus_functions:  list[FunctionItemModel]
    higher_functions: list[FunctionItemModel]
    top_k_lower:      int   = 3
    top_k_higher:     int   = 2
    threshold:        float = 0.55
    strategy:         str   = "llm"   # "llm" | "embeddings"


@router.post("/similarity/suggest")
def similarity_suggest(req: SuggestRequest):
    to_fi = lambda m: FunctionItem(id=m.id, name=m.name, elementName=m.elementName)
    lower  = [to_fi(f) for f in req.lower_functions]
    focus  = [to_fi(f) for f in req.focus_functions]
    higher = [to_fi(f) for f in req.higher_functions]

    if req.strategy == "embeddings":
        suggestions = suggest_by_embeddings(lower, focus, higher, req.top_k_lower, req.top_k_higher, req.threshold)
    else:
        suggestions = suggest_by_llm(lower, focus, higher, llm, req.top_k_lower, req.top_k_higher)

    return {"suggestions": suggestions}


# ═════════════════════════════════════════════════════════════════════════════
# 10. IMPORT PARSE  (from routers_import_parse.py)
# ═════════════════════════════════════════════════════════════════════════════

@router.post("/import/parse")
async def import_parse(
    file:       UploadFile = File(...),
    case:       str        = Form("new_use_case"),
    sheet_name: str        = Form(""),
):
    suffix = Path(file.filename or "upload.xlsx").suffix or ".xlsx"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name

    try:
        parsed = parse_dfmea_file(tmp_path, sheet_name or None)
        parsed = apply_consolidation(parsed)
    except Exception as e:
        return JSONResponse(status_code=422, content={"error": str(e)})
    finally:
        Path(tmp_path).unlink(missing_ok=True)

    # Re-use the same payload builders from the original router
    from routers_import_parse import build_case2_payload, build_case3_payload
    if case == "design_change":
        return build_case3_payload(parsed)
    return build_case2_payload(parsed)


# ═════════════════════════════════════════════════════════════════════════════
# 11. EXPORT  (from export_template.py / export_ifmea_template.py)
# ═════════════════════════════════════════════════════════════════════════════

class RowIn(BaseModel):
    focus_element:      str
    lower_element:      str
    focus_function:     str
    failure_mode:       str
    failure_effect:     str
    severity:           Optional[int] = None
    occurrence:         Optional[int] = None
    failure_cause:      str
    prevention_methods: str
    detection_methods:  str
    detection:          Optional[int] = None
    rpn:                Optional[int] = None


class ExportReq(BaseModel):
    rows: List[RowIn]


class IFMEARowIn(BaseModel):
    interface_element1:      str
    interface_element2:      str
    nominal_transfer:        str
    failure_mode:            str
    failure_effect:          Optional[str] = ""
    failure_cause:           str
    severity:                Optional[int] = None
    current_design_controls: Optional[str] = ""
    prevention_controls:     Optional[str] = ""
    occurrence:              Optional[int] = None
    detection_controls:      Optional[str] = ""
    detection:               Optional[int] = None
    rpn:                     Optional[int] = None


class IFMEAExportReq(BaseModel):
    rows: List[IFMEARowIn]


@router.post("/export/template")
def export_template(req: ExportReq):
    try:
        buf = export_dfmea_to_buffer([r.dict() for r in req.rows])
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="DFMEA_filled.xlsx"'},
    )


@router.post("/ifmea/export/template")
def export_ifmea_template(req: IFMEAExportReq):
    try:
        buf = export_ifmea_to_buffer([r.dict() for r in req.rows])
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="IFMEA_filled.xlsx"'},
    )
