"""
main.py
=======
FastAPI application entry point.
Run: uvicorn main:app --reload --port 8000
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routers.graph_router import router as dfmea_router

app = FastAPI(title="DFMEA LangGraph API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(dfmea_router)


@app.get("/health")
def health():
    return {"status": "ok"}
